var debugChordSequence = "";

function NoteType(abbreviation, tonalPitchClass) {
	var letters = "C D EF G A B";
	this.midiPitch = letters.indexOf(abbreviation.charAt(0));
	
	for (var i = 1; i < abbreviation.length; i++) {
		switch (abbreviation.charAt(i)) {
		case "#":
			this.midiPitch = (this.midiPitch + 1) % 12;
			break;
		case "b":
			this.midiPitch = (this.midiPitch - 1 + 12) % 12;
			break;
		}
	}

	this.abbreviation = abbreviation;
	this.tonalPitchClass = tonalPitchClass;
	
	this.toString = function () {
		return this.abbreviation;
	};
}

var noteTypes = [];
var chordTypes = new Array(256);

function init() { }

function initImpl() {
	var prev = null;
	
	var lines = [];
	var file = new QFile(pluginPath + "/tpc.txt");
	if (!file.open(QIODevice.ReadOnly)) {
		QMessageBox.information(0, "error", file.errorString());
		return;
	}
	var stream = new QTextStream(file);
	while (!stream.atEnd()) {
		lines.push(stream.readLine().split(/[\s]+/));
	}
	file.close();

	var c = null; // The note C (aka Do).
	for (var i = 1; i < lines[0].length; i += 2) {
		for (var j = 0; j < lines.length; j++) {
			var current = new NoteType(lines[j][i], +lines[j][i - 1]);
			noteTypes.push(current);
			if (prev) {
				current.fourth = prev;
				prev.fifth = current;
			}
			prev = current;
			
			if (current.abbreviation == "C") {
				c = current;
			}
		}
	}

	noteTypes[0].fourth = noteTypes[noteTypes.length - 1];
	noteTypes[noteTypes.length - 1].fifth = noteTypes[0];
	noteTypes.sort(function (x, y) {
		if (x.midiPitch == y.midiPitch) {
			return x.abbreviation < y.abbreviation ? -1 : +1;
		}
		else {
			return x.midiPitch < y.midiPitch ? -1 : +1;
		}
	});
	
	noteTypes.tonality = function (noteType) {
		this.noteType = noteType;
	};
	
	// TODO: Set the actual tonality in the run() function based on additional
	// info it might have (key signature etc.)
	noteTypes.tonality(c);
	
	noteTypes.get = function (midiPitch, prevNoteType) {
		if (!this.noteType) {
			throw new Exception("Have to select a tonality via " + 
				"noteTypes.tonality(NoteType)");
		}
	
		midiPitch %= 12;
		
		var left = this.noteType;
		var right = this.noteType;
		
		if (prevNoteType) {
			left = right = prevNoteType;
		}
		
		while (left.midiPitch != midiPitch && right.midiPitch != midiPitch) {
			left = left.fourth;
			right = right.fifth;
		}
		
		if (left.midiPitch == midiPitch) {
			return left;
		}
		else {
			return right;
		}
	};
	
	chordTypes[1] = new ChordType("", [0, 4, 7], 1);
	chordTypes[16] = new ChordType("m", [0, 3, 7], 16);
	chordTypes[186] = new ChordType("sus2", [0, 2, 7], 186);
	chordTypes[192] = new ChordType("sus4", [0, 5, 7], 192);
}

function removeAllHarmonics() {
	// TODO: Remove all chord names.
}

function ChordType(abbreviation, intervals, id) {
	this.abbreviation = abbreviation;
	this.intervals = intervals;
	this.id = id;
	this.on = new Array(12);
	for (var i = 0; i < 12; i++) {
		this.on[i] = 0;
	}
	for (var i = 0; i < intervals.length; i++) {
		this.on[intervals[i]] = 1;
	}
	this.toString = function () {
		return this.abbreviation;
	};
}

function ChordSlider() {
	// TODO: For now, distinguish only Major, minor and sus chords.
	this.prev = null;
	this.prevNoteType = null;
	this.prevChordType = null;
	
	this.proceed = function (current, currentNoteType, currentChordType) {
		this.prevNoteType = currentNoteType;
		this.prevChordType = currentNoteType;
		if (this.prev != null && current != null &&
			this.prev.base == current.base &&
			this.prev.id == current.id &&
			this.prev.root == current.root) {
			
			debugChordSequence += "-\t";
			return null;
		}
		else if (current == null) {
			debugChordSequence += "?\t";
		}
		else {
			debugChordSequence += currentNoteType + currentChordType + "\t";
		}
		return this.prev = current;
	};
	
	this.next = function (chord) {
		var n = chord.notes;
		
		var bestMatchProb = 0;
		var bestMatch = null;
		var bestNoteType = null;
		var bestChordType = null;
		var on = new Array(12);
		for (var iChord = 0; iChord < chordTypes.length; iChord++) {
			if (!chordTypes[iChord]) {
				continue;
			}
			for (var iTonic = 0; iTonic < n; iTonic++) {
				var tonic = chord.note(iTonic).pitch;
				
				for (var i = 0; i < 12; i++) {
					on[i] = 0;
				}
				for (var iNote = 0; iNote < n; iNote++) {
					var note = chord.note(iNote).pitch;
					var diff = (note % 12 - tonic % 12 + 12) % 12;
					on[diff] = 1;
				}
				
				var add = 0;
				var remove = 0;
				for (var i = 0; i < 12; i++) {
					if (chordTypes[iChord].on[i] && !on[i]) {
						remove++;
					}
					else if (!chordTypes[iChord].on[i] && on[i]) {
						add++;
					}
				}
				var nowProb = 0;
				if (!remove) {
					nowProb = 1 / (add + chordTypes[iChord].intervals.length);
				}
				if (nowProb > bestMatchProb) {
					bestMatchProb = nowProb;
					bestMatch = new Harmony(curScore);
					bestNoteType = noteTypes.get(tonic, this.prevNoteType);
					bestMatch.root = bestNoteType.tonalPitchClass;
					bestChordType = chordTypes[iChord];
					bestMatch.id = bestChordType.id;
				}
			}
		}
		
		return this.proceed(bestMatch, bestNoteType, bestChordType);
	};
}

function addHarmonics() {
	// Add chord names.
	
	var cursor = new Cursor(curScore);
	var selectionEnd = new Cursor(curScore);
	
	cursor.goToSelectionStart();
	selectionEnd.goToSelectionEnd();
	
	// TODO: If there is not selection, operate on the entire score.
	
	var startStaff = cursor.staff;
	var endStaff = selectionEnd.staff;
	var staff = startStaff;
	var voice = 0;
	cursor.voice = voice;
	cursor.staff = staff;
	
	print("Start staff: " + startStaff);
	print("End staff: " + endStaff);
	
	// TODO: For now, operate on just the first staff,
	// using only the first voice.
	var slider = new ChordSlider();
	while (cursor.tick() < selectionEnd.tick()) {
		if (cursor.isChord()) {
			var chordType = slider.next(cursor.chord());
			// Add chord title to the score.
			if (chordType) {
				cursor.chord().addHarmony(chordType);
			}
		}
		
		cursor.next();
	}
}

function run() {
	initImpl();
	
	print("Entering run()");
	
	if (typeof curScore === "undefined") {
		print("No score is open.");
		return;
	}
	
	if (curScore.hasHarmonies) {
		print("We already have chord names filled in, have to overwrite.");
		removeAllHarmonics();
	}
	
	addHarmonics();
	
	print(debugChordSequence);
	
	print("Exiting run()");
}

function close() {
}

var mscorePlugin = {
	menu: "Plugins.Magic Chords",
	init: init,
	run: run,
	onClose: close
};

mscorePlugin;
